package com.teo15.picktimebe.coupon;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CouponData {
    private String couponTitle;
    private String couponImage;
}