package com.teo15.picktimebe.coupon;

import com.teo15.picktimebe.gift.Gift;
import com.teo15.picktimebe.gift.GiftRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class CouponService {
    private final CouponRepository couponRepository;
    public List<Coupon> getCouponListForTarget(Long targetId) {

        return null;
    }

}
