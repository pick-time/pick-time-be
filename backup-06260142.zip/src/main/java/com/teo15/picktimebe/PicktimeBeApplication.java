package com.teo15.picktimebe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PicktimeBeApplication {

	public static void main(String[] args) {
		SpringApplication.run(PicktimeBeApplication.class, args);
	}

}
